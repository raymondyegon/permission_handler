## 2.0.2

* Added support for the limited photos permission available on iOS 14 and up.

## 2.0.1

* Update `platform_interface 1.0.2`
* Fix bug which allows requesting is the device has phone capabilities.

## 2.0.0

- **BREAKING**: Created a much more intuitive API using Dart's new extension methods ([#230](https://github.com/Baseflow/flutter-permission-handler/issues/230)). Big thank you to [@marcelgarus](https://github.com/marcelgarus) for the idea and doing all the grunt work.

## 1.0.0

- Initial open-source release.
