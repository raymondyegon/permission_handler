---

name: 🔙 Regression
about: Report unexpected behavior that worked previously
---

## 🔙 Regression

<!--- Summary description of the regression --->

### Old (and correct) behavior

### Current behavior

### Reproduction steps

### Configuration

**Version:** 1.x

**Platform:** 
- [ ] :iphone: iOS
- [ ] :robot: Android